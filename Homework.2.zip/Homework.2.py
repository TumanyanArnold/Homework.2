example = 'Топинамбур'
#1
print (example[0])
#2
print (example[9])
#3
print (example[5:10 ])
#4
print(example [::-1])
print(''.join(reversed(example)))
#5
print(example[1:10:2])     #+example[])
